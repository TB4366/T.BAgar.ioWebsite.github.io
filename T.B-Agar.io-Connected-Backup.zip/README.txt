T.B Agar.io connected demo backup

Files:
- paidskins-connected.html
- Admin-connected.html

Shared storage:
- Shop registration saves users to localStorage key: tb_agar_users
- Shop purchases save to localStorage key: tb_agar_purchases
- Admin reads the same keys and can edit coins/usernames.

Admin demo login:
Username: admin
Password: TBAdmin2026

IMPORTANT:
This is a GitHub Pages / browser-only demo connection. localStorage is tied to the same browser and device, so it is NOT a real multi-user database and must not be used for real passwords or payments.
For a real public shop, replace this with a server backend/database and hashed passwords.
