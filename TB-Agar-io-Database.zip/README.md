# T.B Agar.io Database

## Start
1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Shop: `http://localhost:3000/paidskins.html`
6. Admin: `http://localhost:3000/Admin.html`

Admin login stays exactly:
- Username: `admin`
- Password: `TBAdmin2026`

The server creates/uses `data/tb_agar.sqlite`. Shop accounts, coins and purchases are stored centrally. Passwords are bcrypt-hashed.
