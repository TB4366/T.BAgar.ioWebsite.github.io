T.B Agar.io Website Backup
==========================
Backup name: T.B-Agar.io-Website-Backup
Created: 2026-09-18

Files included:
- Admin.html
- paidskins.html

Important:
These pages are frontend files. The API/backend and database are not contained in this backup.
Keep a separate backup of the backend/database when those are created.
